package hw5_1_compiler;

public class ProgramNode {
	public ProgramNode(){
		
	}
	public void traverse(){
		System.out.println("[ProgramNode] traverse to create bytecode");
	}
	public void getBytecode(){
		System.out.println("[ProgramNode] getBytecode");
	}
}
