package hw5_1_compiler;

public class Scanner {
	public Scanner(){
		
	}
	
	public void readfile(String file){
		System.out.println("[Scanner] Reading from \""+file+"\" and save in Tokens");
	}
	
	public void getTokens(){
		System.out.println("[Scanner] getTokens");
	}
}
