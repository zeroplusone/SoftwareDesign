import java.util.ArrayList;

public class Node {
	private ArrayList<Node> children;
	public void use(Operation op){}
}
