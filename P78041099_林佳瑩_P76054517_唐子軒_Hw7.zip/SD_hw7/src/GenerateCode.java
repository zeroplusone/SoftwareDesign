
public class GenerateCode implements Operation{

	@Override
	public void operate(VariableRefNode node) {
		// TODO Auto-generated method stub
		System.out.println("GenerateCode variableRefNode");
	}

	@Override
	public void operate(AssignmentNode node) {
		// TODO Auto-generated method stub
		System.out.println("GenerateCode AssignmentNode");
	}

}
