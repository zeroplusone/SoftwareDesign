
public interface Operation {
	public void operate(VariableRefNode node);
	public void operate(AssignmentNode node);
}
