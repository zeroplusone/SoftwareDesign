package hw2_Composition;

public class ArrayComposition implements Algorithm {

	public void myAlgorithm() {
		System.out.println("choose Array Composition algorithm");
	}
}
