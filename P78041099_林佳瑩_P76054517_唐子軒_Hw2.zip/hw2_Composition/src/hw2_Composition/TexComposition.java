package hw2_Composition;

public class TexComposition implements Algorithm {

	public void myAlgorithm() {
		System.out.println("choose Tex Composition algorithm");
	}
}
