package hw2_Composition;

public interface Algorithm {

	public void myAlgorithm();

}
