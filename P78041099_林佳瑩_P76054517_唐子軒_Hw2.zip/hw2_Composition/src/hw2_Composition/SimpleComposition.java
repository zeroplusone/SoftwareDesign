package hw2_Composition;

public class SimpleComposition implements Algorithm {

	public void myAlgorithm() {
		System.out.println("choose Simple Composition algorithm");
	}
}
