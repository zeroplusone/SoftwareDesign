package sd_hw6;

public class LibraryA {
	public void funcA(){
		System.out.println("This is Library A.");
	}
}
