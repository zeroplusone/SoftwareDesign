package sd_hw6;

public class MappingB implements LibraryController{

	@Override
	public void func() {
		// TODO Auto-generated method stub
		LibraryB lib = new LibraryB();
		lib.funcB();
	}

}
