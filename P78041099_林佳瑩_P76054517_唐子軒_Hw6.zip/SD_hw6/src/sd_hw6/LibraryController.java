package sd_hw6;

public interface LibraryController {
	public void func();
}
