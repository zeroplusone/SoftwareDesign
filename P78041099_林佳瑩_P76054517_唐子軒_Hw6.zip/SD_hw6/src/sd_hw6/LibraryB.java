package sd_hw6;

public class LibraryB {
	public void funcB(){
		System.out.println("This is Library B.");
	}
}
