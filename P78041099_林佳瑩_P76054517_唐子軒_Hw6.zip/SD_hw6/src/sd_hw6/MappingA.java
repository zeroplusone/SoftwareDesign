package sd_hw6;

public class MappingA implements LibraryController{

	@Override
	public void func() {
		// TODO Auto-generated method stub
		LibraryA lib = new LibraryA();
		lib.funcA();
	}

}
