package App;

public class PresentationManager implements Standards {

	@Override
	public ScrollBar createScrollBar() {
		return new PMScrollBar();
		
	}

	@Override
	public Button createButton() {
		return new PMButton();
		
	}

	@Override
	public Window createWindow() {
		return new PMWindow();
		
	}

}
