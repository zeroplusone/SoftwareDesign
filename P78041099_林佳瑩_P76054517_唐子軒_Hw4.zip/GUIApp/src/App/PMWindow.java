package App;

public class PMWindow extends Window {
	PMWindow(){
		System.out.println("I'm PMWindow");
	}
}
