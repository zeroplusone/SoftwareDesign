package App;

public class MotifWindow extends Window {
	MotifWindow(){
		System.out.println("I'm MotifWindow");
	}
}
