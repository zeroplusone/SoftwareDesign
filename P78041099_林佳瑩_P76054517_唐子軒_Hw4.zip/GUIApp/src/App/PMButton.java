package App;

public class PMButton extends Button {
	PMButton(){
		System.out.println("I'm PMButton");
	}
}
