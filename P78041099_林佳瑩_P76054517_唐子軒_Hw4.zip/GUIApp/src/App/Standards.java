package App;

public interface Standards {

	public ScrollBar createScrollBar();
	public Button createButton();
	public Window createWindow();
	
}
