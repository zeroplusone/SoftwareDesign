package App;

import java.awt.List;
import java.util.Scanner;

public class GUI {
	
	public static void main(String argv[]){
		
		Standards style = null;
		Scanner scanner = new Scanner(System.in);
		String inputWidget;
		String inputStyle;
		
		System.out.println("Choose the Style : (1:Motif 2:Presentation Manager)");
		inputStyle = scanner.nextLine();
		System.out.println("Choose the Widget : (1:Windows 2:Button 3:ScrollBar)");
		inputWidget = scanner.nextLine();
		
		if(inputStyle.equals("1") ){
			style = new Motif();
		}else if(inputStyle.equals("2")){
			style = new PresentationManager();
		}
		
		if(inputWidget.equals("1") ){
			style.createWindow();
		}else if(inputWidget.equals("2")){
			style.createButton();
		}else if(inputWidget.equals("3")){
			style.createScrollBar();
		}
		
		
		
	}
}
