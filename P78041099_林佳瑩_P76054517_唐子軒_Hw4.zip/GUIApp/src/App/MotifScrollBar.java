package App;

public class MotifScrollBar extends ScrollBar {
	MotifScrollBar(){
		System.out.println("I'm MotifScrollBar");
	}
}
