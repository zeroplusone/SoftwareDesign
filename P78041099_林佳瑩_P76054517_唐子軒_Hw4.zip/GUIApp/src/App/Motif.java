package App;

public class Motif implements Standards {

	@Override
	public ScrollBar createScrollBar() {
		return new MotifScrollBar();
	}

	@Override
	public Button createButton() {
		return new MotifButton();
	}

	@Override
	public Window createWindow() {
		return new MotifWindow();
	}

}
