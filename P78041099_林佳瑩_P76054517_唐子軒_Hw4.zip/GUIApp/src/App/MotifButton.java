package App;

public class MotifButton extends Button {
	MotifButton(){
		System.out.println("I'm MotifButton");
	}
}
