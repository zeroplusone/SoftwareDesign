package App;

public class PMScrollBar extends ScrollBar {
	PMScrollBar(){
		System.out.println("I'm PMScrollBar");
	}
}
